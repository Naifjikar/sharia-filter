
import requests

def check_sharia_compliance(symbol):
    responses = {}

    try:
        r1 = requests.get(f'https://chart-idea.com/filter?q={symbol}')
        responses["Chart Idea"] = "مباح" if "مباح" in r1.text else "غير واضح"
    except:
        responses["Chart Idea"] = "تعذر الاتصال"

    try:
        r2 = requests.get(f'https://yaaqen.com/stocks/{symbol}')
        responses["Yaqeen"] = "مباح" if "مباح" in r2.text else "غير واضح"
    except:
        responses["Yaqeen"] = "تعذر الاتصال"

    try:
        r3 = requests.get(f'https://filterna.com/stocks/{symbol}')
        responses["Filterna"] = "مباح" if "مباح" in r3.text else "غير واضح"
    except:
        responses["Filterna"] = "تعذر الاتصال"

    return responses

if __name__ == "__main__":
    symbol = input("أدخل رمز السهم: ").strip().upper()
    results = check_sharia_compliance(symbol)
    for source, result in results.items():
        print(f"{source}: {result}")
